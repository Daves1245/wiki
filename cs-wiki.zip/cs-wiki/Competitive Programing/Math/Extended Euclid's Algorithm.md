#competitive-programming #math 
[[Math]]