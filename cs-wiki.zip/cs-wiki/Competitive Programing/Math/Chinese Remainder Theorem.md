#competitive-programming #math
[[Math]]