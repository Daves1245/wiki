[[Techniques & Paradigms]]
