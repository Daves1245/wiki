#competitive-programmingt #strings 

[[Strings]]