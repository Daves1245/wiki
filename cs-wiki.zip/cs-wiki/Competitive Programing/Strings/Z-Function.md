#competitive-programming #strings 

[[Strings]]