#competitive-programming #strings 
[[Strings]]
