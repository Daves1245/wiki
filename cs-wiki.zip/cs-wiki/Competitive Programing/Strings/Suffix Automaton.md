#competitive-programming #strings 
[[Strings]]