#competitive-programming #strings
[[Strings]]