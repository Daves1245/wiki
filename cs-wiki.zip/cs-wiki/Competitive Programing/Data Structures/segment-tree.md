#data-structures #trees 

[[Data Structures]]
[[Graphs]]
[[Trees]]

