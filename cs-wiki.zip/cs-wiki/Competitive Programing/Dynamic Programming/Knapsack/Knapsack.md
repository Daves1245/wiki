#competitive-programming #dynamic-programming 
[[Dynamic Programming]]

[[0-1 Knapsack]]
[[0-K Knapsack]]
[[0-Inf Knapsack]]
